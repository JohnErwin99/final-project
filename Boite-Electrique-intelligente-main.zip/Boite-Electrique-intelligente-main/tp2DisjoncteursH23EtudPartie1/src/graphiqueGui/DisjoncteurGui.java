package graphiqueGui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import disjoncteurs.Boite;
import disjoncteurs.Disjoncteur;
import hierarchieAppareils.AppareilAbstrait;
import utile.UtilitaireGestionMenu;;

class DisjoncteurGui extends JPanel implements ActionListener{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel;
	PanneauDisjoncteurs panneauDisjoncteur;
	Boite boite;
	Disjoncteur disjoncteur;
    private int ligne;
    private int colonne;

    public DisjoncteurGui(Boite boite, PanneauDisjoncteurs panneauDisjoncteur, Disjoncteur disjoncteur, int ligne, int colonne) {
    	this.disjoncteur = disjoncteur;
    	this.panneauDisjoncteur = panneauDisjoncteur;
    	this.boite = boite;
        this.ligne = ligne;
        this.colonne = colonne;

        if (disjoncteur == null) {
            JButton btnVide = new JButton();
            btnVide.setPreferredSize(new Dimension(200, 30));
            btnVide.setEnabled(false);
            add(btnVide);

            JButton btnGris = new JButton("vide");
            btnGris.setBackground(Color.GRAY);
            btnGris.setPreferredSize(new Dimension(200, 30));
            btnGris.setEnabled(true);
            btnGris.addActionListener(this);
            add(btnGris);
        } else {
            // Bouton avec les données du disjoncteur
            JButton btnDonnees = new JButton(disjoncteur.getAmpere() + "/" + 
            disjoncteur.getTension() + disjoncteur.getPuissanceEnWatt());
            btnDonnees.setPreferredSize(new Dimension(200, 30));
            btnDonnees.setEnabled(true);
            btnDonnees.addActionListener(this);
            add(btnDonnees);

            // Interrupteur dans le bon état
            String etatAllume = String.valueOf(disjoncteur.getEtat());
            InterrupteurGui interrupteurGui = new InterrupteurGui(etatAllume, disjoncteur, ligne, colonne);
            add(interrupteurGui);
        }
    }
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			try {
				
					

				if(this.disjoncteur==null) {
					UtilitaireGestionMenu.ajouterDisjoncteur(boite, ligne, colonne);
				  mettreAJourPanneaux();
				}
				else {
					AppareilAbstrait appareil = FenetreSaisieAppareil.getAppareil();
				         if (appareil.getTension() == disjoncteur.getTension()) {
                    disjoncteur.ajouterAppareil(appareil);  
                    mettreAJourPanneaux();
                   } else {
                        JOptionPane.showMessageDialog(this, "Les tensions doivent être égales.");
                     }
			       
				}
			}catch(Exception a) {
				e.toString();
			}
			
		}
		
		public void mettreAJourPanneaux() {
			//removeAll();
			panneauDisjoncteur.removeAll();
			

	        // Ajoutez des nouveaux boutons et éléments à panneauInfoBoite et panneauDisjoncteur ici
			

           // validate();
            panneauDisjoncteur.revalidate();
            panneauDisjoncteur.validate();
            panneauDisjoncteur.repaint();
	       // repaint();
	        
	        panneauDisjoncteur.ajouterDisjoncteurs();
		}
    }
    

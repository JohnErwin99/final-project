package graphiqueGui;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.*;

import disjoncteurs.Boite;

public class PanneauPrincipal extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected Boite boite;
    private PanneauInfoBoite panneauInfoBoite;
    private PanneauDisjoncteurs panneauDisjoncteurs;
    private MenuBarPersonnalisee menubar;

    public PanneauPrincipal(CadreBoiteDisjonction cadreboite, Boite boite) {
        this.boite = boite;
        
        panneauInfoBoite = new PanneauInfoBoite(boite);
        panneauDisjoncteurs = new PanneauDisjoncteurs(boite);
        
        add(panneauInfoBoite, BorderLayout.WEST);
        add(panneauDisjoncteurs, BorderLayout.EAST);

        setVisible(true);
    }
    
    public void setBoite(Boite Nouvelboite) {
    	
    	removeAll();
    	
    	
		revalidate();
	      validate();
          repaint();
          
        
		this.boite = Nouvelboite;

	        
	      add(new PanneauInfoBoite(Nouvelboite), BorderLayout.WEST);
	      add(new PanneauDisjoncteurs(Nouvelboite), BorderLayout.EAST);
	      
	     setVisible(true);
    }
}

/**
 * 
 */
package graphiqueGui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import disjoncteurs.Disjoncteur;

/**
 * @author jerwin
 *
 */
public class InterrupteurGui extends JPanel{
	private JPanel panel;
    private int ligne;
    private int colonne;
	public InterrupteurGui(String etat, Disjoncteur disjoncteur, int ligne, int colonne) {
		if (etat == "ALLUME") {
            JButton btnNoir = new JButton();
            btnNoir.setBackground(Color.BLACK);
            btnNoir.setPreferredSize(new Dimension(100, 30)); // La moitié de la taille du bouton pour un disjoncteur.
            btnNoir.setEnabled(false);
            add(btnNoir);

            JButton btnBlanc = new JButton();
            btnBlanc.setBackground(Color.WHITE);
            btnBlanc.setPreferredSize(new Dimension(100, 30)); 
            btnBlanc.setEnabled(false);
            add(btnBlanc);
        } else {
            JButton btnRouge = new JButton();
            btnRouge.setBackground(Color.RED);
            btnRouge.setPreferredSize(new Dimension(100, 30));
            btnRouge.addActionListener(new SwitchButtonListener(disjoncteur));
            btnRouge.setEnabled(true);
            add(btnRouge);

            JButton btnNoir = new JButton();
            btnNoir.setBackground(Color.BLACK);
            btnNoir.setPreferredSize(new Dimension(100, 30)); 
            btnNoir.setEnabled(true);
            add(btnNoir);
        }
	}
	
	  class SwitchButtonListener implements ActionListener {
	        private Disjoncteur disjoncteur;

	        public SwitchButtonListener(Disjoncteur disjoncteur) {
	            this.disjoncteur = disjoncteur;
	        }

			@Override
			public void actionPerformed(ActionEvent e) {
				//FenetreSaisieAppareil.getAppareil();	
				FenetreAppareils resultat = new FenetreAppareils(disjoncteur);
				
			}
	    }
}

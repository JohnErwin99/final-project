package graphiqueGui;

import javax.swing.*;

import disjoncteurs.Disjoncteur;
import hierarchieAppareils.AppareilAVariateur;
import hierarchieAppareils.AppareilAbstrait;
import hierarchieAppareils.AppareilInterrupteur;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class FenetreAppareils extends JDialog implements ActionListener{
    private Disjoncteur disjoncteur;
    private JPanel panneauAppareils;

    public FenetreAppareils(Disjoncteur disjoncteur) {
        this.disjoncteur = disjoncteur;
        setTitle("Appareils");
        setSize(400, 1000);
        setModal(true);
        setLocationRelativeTo(null);

        panneauAppareils = new JPanel();
        panneauAppareils.setLayout(new BoxLayout(panneauAppareils, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(panneauAppareils);
        add(scrollPane);

        afficherAppareils();

        setVisible(true);
    }
    

    private void afficherAppareils() {   
    	        try {
    	        	for (AppareilAbstrait appareil : disjoncteur.getTabAppareils()) {
    		 
    	        		panneauAppareils.add(new JLabel("Catégorie:"));
    	        		panneauAppareils.add(new JLabel(appareil.getCategorie()));

    	        		panneauAppareils.add(new JLabel("Emplacement:"));
    	        		panneauAppareils.add(new JLabel(appareil.getEmplacement()));

    	        		panneauAppareils.add(new JLabel("Ampérage:"));
    	        		panneauAppareils.add(new JLabel(String.valueOf(appareil.getAmperage())));

    	        		panneauAppareils.add(new JLabel("Tension:"));
    	        		panneauAppareils.add(new JLabel(String.valueOf(appareil.getTension())));

    	        		panneauAppareils.add(new JLabel("État:"));

    	        if (appareil.estAllume()) {
    	        	panneauAppareils.add(new JLabel());
    	        } else {
    	            JLabel etatLabel = new JLabel("X");
    	            etatLabel.setForeground(Color.RED);
    	            panneauAppareils.add(etatLabel);
    	        }

    	        panneauAppareils.add(new JLabel("Type d'appareil:"));
    	       
    	      
    	        
    	        JCheckBox  checkBox = new JCheckBox("Interrupteur");checkBox.setEnabled(false);
                	panneauAppareils.add(checkBox);
                JCheckBox checkBox2 = new JCheckBox("Variateur");checkBox2.setEnabled(false);
                	panneauAppareils.add(checkBox2);
                	
                	 JButton retirerBtn = new JButton("retirer appareil");
                	 retirerBtn.addActionListener(this);
                	 panneauAppareils.add(retirerBtn);
                	 
                if(appareil.estVariateur() == true) {
                	checkBox.isSelected();
                }
                else {
                	checkBox2.isSelected();
                }

                }
    	        	}catch(Exception e) {
    	        	e.toString();
    	        }
    	 
    	 add(panneauAppareils);
    }


	@Override
	public void actionPerformed(ActionEvent e) {
		disjoncteur.retirerAppareil(0);
		
	}
}

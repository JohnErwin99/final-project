package graphiqueGui;
import javax.swing.*;

import disjoncteurs.Boite;
import utile.UtilitaireESFichier;
import utile.UtilitaireGestionMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class MenuBarPersonnalisee extends JMenuBar {
	private PanneauPrincipal panneauPrincipal;

    public MenuBarPersonnalisee(PanneauPrincipal panneauPrincipal, Boite boite) {
        this.panneauPrincipal = panneauPrincipal;

        JMenu fichierMenu = new JMenu("Fichier");
        add(fichierMenu);

        JMenuItem nouvelleBoite = new JMenuItem("Nouvelle boîte");
        nouvelleBoite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
                String ampStr = JOptionPane.showInputDialog("Veuillez entrer l'ampérage de la nouvelle boîte :");
                if (ampStr != null) {
                    double amperage = Double.parseDouble(ampStr);
                    //CadreBoiteDisjonction test = new CadreBoiteDisjonction();
                    Boite Nouvelboite = new Boite((int)amperage);
            		Nouvelboite.remplirAlea();
                    panneauPrincipal.setBoite(Nouvelboite);
                    
                }
            }
        });
        fichierMenu.add(nouvelleBoite);

        JMenuItem ouvrir = new JMenuItem("Ouvrir");
        ouvrir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                panneauPrincipal.setBoite(UtilitaireESFichier.recupererBoite());
            }
        });
        fichierMenu.add(ouvrir);

        JMenuItem sauvegarder = new JMenuItem("Sauvegarder");
        sauvegarder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            	UtilitaireESFichier.sauvegarderBoite(panneauPrincipal.boite);
                    
            }
        });
        fichierMenu.add(sauvegarder);

        JMenuItem quitter = new JMenuItem("Quitter");
        quitter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        fichierMenu.add(quitter);
    }
}

package hierarchieAppareils;

public class AppareilAVariateur extends AppareilAbstrait {
    private double positionVariateur;

    public AppareilAVariateur(String categorie, int tension, double amperage, boolean etat, String emplacement, double positionVariateur) {
        super(categorie, tension, amperage, etat, emplacement);
        this.positionVariateur = positionVariateur;
    }

    public AppareilAVariateur(String categorie, double amperage, int tension, String emplacement, double positionVariateur) {
        super(categorie, amperage, tension, emplacement);
        this.positionVariateur = positionVariateur;

	}

	@Override
    public boolean estVariateur() {
        return true;
    }

    @Override
    public double getPuissance() {
        return etat ? tension * amperage * positionVariateur : 0;
    }

    @Override
    public boolean estAllume() {
        return etat;
    }

    public double getPositionVariateur() {
        return positionVariateur;
    }

    public void setPositionVariateur(double positionVariateur) {
        this.positionVariateur = positionVariateur;
    }
}

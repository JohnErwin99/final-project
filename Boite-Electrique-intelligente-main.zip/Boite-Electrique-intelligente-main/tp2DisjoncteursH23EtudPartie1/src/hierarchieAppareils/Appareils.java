package hierarchieAppareils;

public interface Appareils {
	boolean estVariateur();
    double getPuissance();
    boolean estAllume();
}

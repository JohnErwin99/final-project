package hierarchieAppareils;

public class AppareilInterrupteur extends AppareilAbstrait{

	public AppareilInterrupteur(String categorie, int tension, double amperage, boolean etat, String emplacement) {
		super(categorie, tension, amperage, etat, emplacement);
		// TODO Auto-generated constructor stub
	}

	public AppareilInterrupteur(String categorie, double amperage, int tension, String emplacement) {
		super(categorie, amperage, tension, emplacement);
	}

	@Override
	public boolean estVariateur() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double getPuissance() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean estAllume() {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}

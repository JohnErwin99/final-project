package hierarchieAppareils;

public abstract class AppareilAbstrait implements Appareils{
	
	protected String categorie;
    protected int tension;
    protected double amperage;
    protected boolean etat;
    protected String emplacement;
    
    public AppareilAbstrait(String categorie, int tension, double amperage, boolean etat, String emplacement) {
        this.categorie = categorie;
        this.tension = tension;
        this.amperage = amperage;
        this.etat = etat;
        this.emplacement = emplacement;
    }
    
    
    public AppareilAbstrait(String categorie, double amperage, int tension, String emplacement) {
    	this.categorie = categorie;
        this.tension = tension;
        this.amperage = amperage;
        this.emplacement = emplacement;
	}


	public String getCategorie() {
		return categorie;
	}


	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}


	public int getTension() {
		return tension;
	}


	public void setTension(int tension) {
		this.tension = tension;
	}


	public double getAmperage() {
		return amperage;
	}


	public void setAmperage(double amperage) {
		this.amperage = amperage;
	}


	public String getEmplacement() {
		return emplacement;
	}


	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}


	public boolean isEtat() {
		return etat;
	}


	public void setEtat(boolean etat) {
        this.etat = etat;
    }
}
